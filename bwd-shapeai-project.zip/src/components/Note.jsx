import React from "react";

function Note() {
  return (
    <div className="note">
      <p>
        This is Web Development with JavaScript and React.js bootcamp conducted
        by ShapeAI.
      </p>
      <p>
        The instructor taught everything from scratch and gave introdyctions
        about JavaScript,HTML and React.js
      </p>
      <p>This is the project that has to be submitted to get a certificate.</p>
    </div>
  );
}
export default Note;
